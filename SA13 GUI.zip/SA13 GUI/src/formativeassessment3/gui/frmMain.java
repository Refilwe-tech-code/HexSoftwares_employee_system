
package formativeassessment3.gui;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author User
 */
public class frmMain extends javax.swing.JFrame {

    /**
     * Creates new form frmMain
     */
    public frmMain() {
        initComponents();
    }
    Boolean boolRecordExists=false;
    String strEmployeeID= "EmployeeID";
    String strEmployeeFirstNameandLastName= "EmployeeFirstNameandLastName";
    String strEmployeeGender="EmployeeGender";
    String strEmployeeDateofBirth="EmployeeDateofBirth";
    String strEmployeeEmail="mployeeEmail";
    String strPosition="Position";
    String strDepartment= "Department";
    String strStartingDate="StartingDate";
    String strEmployeeContactInformation="mployeeContactInformation";
    
    
    private void mGetValuesFromGUI() {
        strEmployeeID=txtEmployeeID.getText();
        strEmployeeFirstNameandLastName=txtEmployeeFirstNameandLastName.getText();
        strEmployeeGender=txtEmployeeGender.getText();
        strEmployeeDateofBirth=txtEmployeeDateofBirth.getText();
        strEmployeeEmail=txtEmployeeEmail.getText();
        strPosition=txtPosition.getText();
        strDepartment=txtDepartment.getText();
        strStartingDate=txtStartingDate.getText();
        strEmployeeContactInformation=txtEmployeeContactInformation.getText();
        
    }
    
    private void mSetValuesToUpperCase() {
        strEmployeeID=strEmployeeID.toUpperCase();
        strEmployeeFirstNameandLastName=strEmployeeFirstNameandLastName.toUpperCase();
        strEmployeeGender=strEmployeeGender.toUpperCase();
        strEmployeeDateofBirth=strEmployeeDateofBirth.toUpperCase();
        strEmployeeEmail=strEmployeeEmail.toUpperCase();
        strPosition=strPosition.toUpperCase();
        strDepartment=strDepartment.toUpperCase();
        strStartingDate=strStartingDate.toUpperCase();
        strEmployeeContactInformation=strEmployeeContactInformation.toUpperCase();
         
    }
    
    private void mCheckIfItemsExistInTable() {
        String strDBConnectionString= "jdbc:mysql://localhost:3306/employee_db";
        String strDBUser="root";
        String strDBPassword="39ha2212796";
        java.sql.Connection conMySQLConnectionString;
        java.sql.Statement stStatement=null;
        ResultSet rs= null;
        
        try
        {
            conMySQLConnectionString= DriverManager.getConnection(strDBConnectionString, strDBUser,strDBPassword);
            stStatement= conMySQLConnectionString.createStatement();
            String strQuery = " Select * from employee_records where Name ='" + strEmployeeID + "' , EmployeeID = '" + strEmployeeFirstNameandLastName + "' , EmployeeFirstNameandLastName = '" + strEmployeeGender + "' , EmployeeGender  = '" + strEmployeeDateofBirth + "' , EmployeeDateofBirth = '" + strEmployeeEmail + "EmployeeEmail'" + strPosition + "' , Position = '" + strDepartment + "' , Department = '" + strStartingDate + "' , StartingDate = '" + strEmployeeContactInformation + "' , EmployeeContactInformation = '";
                                                                                                                                                                                                                               
            stStatement.execute(strQuery);
            rs=stStatement.getResultSet();
            boolRecordExists=rs.next();
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally
        {
            try
            {
                stStatement.close();
            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(null, "Connection String not closed" + " " + e);
                
            }    
        }    
    }
    
    public void mCreateActor() {
        java.sql.Connection conMySQLConnectionString= null;
        String URL= "jdbc:mysql://localhost:3306/employee_db";
        String User="root";
        String Password="39ha2212796";
        try
        {
            conMySQLConnectionString = DriverManager.getConnection(URL,User,Password);
            java.sql.Statement myStatement= conMySQLConnectionString.createStatement();
            String sqlinsert = " insert into employee_records " + " (EmployeeID, EmployeeFirstNameandLastName, EmployeeGender, EmployeeDateofBirth, EmployeeEmail, EmployeePosition, EmployeeDepartment, EmployeeStartingDate, EmployeeEmergencyContactInformation) " + "values('"+ strEmployeeID +"', '"+strEmployeeFirstNameandLastName+"', '"+ strEmployeeGender +"', '"+ strEmployeeDateofBirth +"', '"+ strEmployeeEmail +"', '"+ strPosition +"', '"+ strDepartment +"', '"+ strStartingDate +"', '"+ strEmployeeContactInformation +"')";  
            myStatement.executeUpdate(sqlinsert);
            myStatement.close();
            JOptionPane.showMessageDialog(null, "Complete");
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }    
    }
    
    private void mClearTextFields() {
        txtEmployeeID.setText("");
        txtEmployeeFirstNameandLastName.setText("");
        txtEmployeeGender.setText("");
        txtEmployeeDateofBirth.setText("");
        txtEmployeeEmail.setText("");
        txtPosition.setText("");
        txtDepartment.setText("");
        txtStartingDate.setText("");
        txtEmployeeContactInformation.setText("");
    }
    


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblBusinessConferenceAttendanceRegister = new javax.swing.JLabel();
        lblEmployeeFirstNameandLastName = new javax.swing.JLabel();
        lblEmployeeGender = new javax.swing.JLabel();
        lblDepartment = new javax.swing.JLabel();
        lblCompany = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnCapture = new javax.swing.JButton();
        btnView = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        lblEmployeeID = new javax.swing.JLabel();
        lblCompany1 = new javax.swing.JLabel();
        txtEmployeeContactInformation = new javax.swing.JLabel();
        lblPosition = new javax.swing.JLabel();
        lblEmployeeDateofBirth = new javax.swing.JLabel();
        txtEmployeeID = new javax.swing.JTextField();
        txtEmployeeFirstNameandLastName = new javax.swing.JTextField();
        txtEmployeeGender = new javax.swing.JTextField();
        txtEmployeeEmail = new javax.swing.JTextField();
        txtPosition = new javax.swing.JTextField();
        txtDepartment = new javax.swing.JTextField();
        txtStartingDate = new javax.swing.JTextField();
        txtEmployeeDateofBirth = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblBusinessConferenceAttendanceRegister.setFont(new java.awt.Font("Tempus Sans ITC", 1, 11)); // NOI18N
        lblBusinessConferenceAttendanceRegister.setText("Employee Registration GUI");

        lblEmployeeFirstNameandLastName.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblEmployeeFirstNameandLastName.setText("Employee First Name and Last Name ");

        lblEmployeeGender.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblEmployeeGender.setText("Employee Gender");

        lblDepartment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblDepartment.setText("Department");

        lblCompany.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblCompany.setText("Starting Date");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Employee First Name and Last Name ", "Employee Gender", "Employee Date of Birth ", "Employee Email", "Position/ job Title ", "Department", "Starting Date ", "Employee ID ", "Emergency Contact Information"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        btnCapture.setText("Capture");
        btnCapture.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCaptureActionPerformed(evt);
            }
        });

        btnView.setText("View");
        btnView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewActionPerformed(evt);
            }
        });

        btnExit.setText("Exit");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        lblEmployeeID.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblEmployeeID.setText("Employee ID");

        lblCompany1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblCompany1.setText("Employee Email");

        txtEmployeeContactInformation.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        txtEmployeeContactInformation.setText("Employee Contact Information");

        lblPosition.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblPosition.setText("Position/Job Title");

        lblEmployeeDateofBirth.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblEmployeeDateofBirth.setText("Employee Date of Birth");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 79, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnCapture, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnView, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnDelete))
                            .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(198, 198, 198))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(lblBusinessConferenceAttendanceRegister, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(304, 304, 304))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblEmployeeGender, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblEmployeeDateofBirth, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtEmployeeGender, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEmployeeDateofBirth, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblEmployeeID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblEmployeeFirstNameandLastName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtEmployeeFirstNameandLastName, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                                    .addComponent(txtEmployeeID))))
                        .addGap(97, 97, 97)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmployeeContactInformation, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblPosition, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                                    .addComponent(lblDepartment, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblCompany1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblCompany, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtEmployeeEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtStartingDate, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(36, 36, 36))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(90, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 840, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(lblBusinessConferenceAttendanceRegister)
                .addGap(69, 69, 69)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(lblEmployeeID, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtEmployeeID, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblEmployeeFirstNameandLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(txtEmployeeFirstNameandLastName, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblEmployeeGender, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblEmployeeDateofBirth, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtEmployeeGender, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtEmployeeDateofBirth, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCompany1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEmployeeEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblPosition)
                            .addComponent(txtPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCompany, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtStartingDate, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(20, 20, 20)
                .addComponent(txtEmployeeContactInformation, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnEdit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCapture)
                        .addComponent(btnView)
                        .addComponent(btnDelete)))
                .addGap(18, 18, 18)
                .addComponent(btnExit)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCaptureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCaptureActionPerformed
        if(txtEmployeeID.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "The field cannot be left empty");
            txtEmployeeID.requestFocusInWindow();
        }
        else if(txtEmployeeFirstNameandLastName.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "The field cannot be left empty");
            txtEmployeeFirstNameandLastName.requestFocusInWindow();
        }
        else if(txtEmployeeGender.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "The field cannot be left empty");
            txtEmployeeGender.requestFocusInWindow();
        }
        else if(txtEmployeeDateofBirth.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "The field cannot be left empty");
            txtEmployeeDateofBirth.requestFocusInWindow();
        }
        else if(txtEmployeeEmail.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "The field cannot be left empty");
            txtEmployeeEmail.requestFocusInWindow();    
        }    
        else if(txtPosition.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "The field cannot be left empty");
            txtPosition.requestFocusInWindow();
        }
        else if(txtDepartment.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "The field cannot be left empty");
            txtDepartment.requestFocusInWindow();
        }
        else if(txtStartingDate.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "The field cannot be left empty");
            txtStartingDate.requestFocusInWindow();
        }
        else if(txtEmployeeContactInformation.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "The field cannot be left empty");
            txtEmployeeContactInformation.requestFocusInWindow();
        }    
        else
        {
            mGetValuesFromGUI();
            mSetValuesToUpperCase();
            mCheckIfItemsExistInTable();
            if(boolRecordExists==true)
            {
                boolRecordExists=false;
                JOptionPane.showMessageDialog(null, "Actor already Exixts");
            }
            else if(boolRecordExists==false)
            {
                mCreateActor();
                mClearTextFields();
            }    
        }    

    }//GEN-LAST:event_btnCaptureActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed

        System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
String strDBConnectionString= "jdbc:mysql://localhost:3306/employee_db";
        String strDBUser="root";
        String strDBPassword="39ha2212796";
        java.sql.Connection conMySQLConnectionString;
        java.sql.Statement stStatement=null;
        ResultSet rs= null;
        
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conMySQLConnectionString= DriverManager.getConnection(strDBConnectionString, strDBUser,strDBPassword);
            stStatement= conMySQLConnectionString.createStatement();
            String strQuery = " Select * from employee_records";
                                                                                                                                                                                                                               
            stStatement.execute(strQuery);
            rs=stStatement.getResultSet();
            ResultSetMetaData rsmd=rs.getMetaData();
            DefaultTableModel model=(DefaultTableModel) jTable1.getModel();
            
            while(rs.next()){
                String strEmployeeID = rs.getString("EmployeeID");
                String strEmployeeFirstNameandLastName = rs.getString("EmployeeFirstNameandLastName");
                String strEmployeeGender = rs.getString("EmployeeGender");
                String strEmployeeDateofBirth = rs.getString("EmployeeDateofBirth");
                String strEmployeeEmail = rs.getString("EmployeeEmail");
                String strPosition = rs.getString("Position");
                String strDepartment = rs.getString("Department");
                String strStartingDate = rs.getString("StartingDate");
                String strEmployeeContactInformation = rs.getString("EmployeeContactInformation");
               
                
            }
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }    
        
    }//GEN-LAST:event_btnViewActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
     String strDBConnectionString= "jdbc:mysql://localhost:3306/employee_db";
        String strDBUser="root";
        String strDBPassword="39ha2212796";
        java.sql.Connection conMySQLConnectionString;
        java.sql.Statement stStatement=null;
        ResultSet rs= null;
        
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conMySQLConnectionString= DriverManager.getConnection(strDBConnectionString, strDBUser,strDBPassword);
            stStatement= conMySQLConnectionString.createStatement();
            String strQuery = " Update * from employee_records";
                                                                                                                                                                                                                               
            stStatement.execute(strQuery);
            rs=stStatement.getResultSet();
            ResultSetMetaData rsmd=rs.getMetaData();
            DefaultTableModel model=(DefaultTableModel) jTable1.getModel();
            
            while(rs.next()){
                String strEmployeeID = rs.getString("EmployeeID");
                String strEmployeeFirstNameandLastName = rs.getString("EmployeeFirstNameandLastName");
                String strEmployeeGender = rs.getString("EmployeeGender");
                String strEmployeeDateofBirth = rs.getString("EmployeeDateofBirth");
                String strEmployeeEmail = rs.getString("EmployeeEmail");
                String strPosition = rs.getString("Position");
                String strDepartment = rs.getString("Department");
                String strStartingDate = rs.getString("StartingDate");
                String strEmployeeContactInformation = rs.getString("EmployeeContactInformation");   
                
            }
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }    
        
                                          
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
     String strDBConnectionString= "jdbc:mysql://localhost:3306/employee_db";
        String strDBUser="root";
        String strDBPassword="39ha2212796";
        java.sql.Connection conMySQLConnectionString;
        java.sql.Statement stStatement=null;
        ResultSet rs= null;
        
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conMySQLConnectionString= DriverManager.getConnection(strDBConnectionString, strDBUser,strDBPassword);
            stStatement= conMySQLConnectionString.createStatement();
            String strQuery = " Delete * from employee_records";
                                                                                                                                                                                                                               
            stStatement.execute(strQuery);
            rs=stStatement.getResultSet();
            ResultSetMetaData rsmd=rs.getMetaData();
            DefaultTableModel model=(DefaultTableModel) jTable1.getModel();
            
            while(rs.next()){
                String strEmployeeID = rs.getString("EmployeeID");
                String strEmployeeFirstNameandLastName = rs.getString("EmployeeFirstNameandLastName");
                String strEmployeeGender = rs.getString("EmployeeGender");
                String strEmployeeDateofBirth = rs.getString("EmployeeDateofBirth");
                String strEmployeeEmail = rs.getString("EmployeeEmail");
                String strPosition = rs.getString("Position");
                String strDepartment = rs.getString("Department");
                String strStartingDate = rs.getString("StartingDate");
                String strEmployeeContactInformation = rs.getString("EmployeeContactInformation");
               
                
            }
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }    
        
            
    }//GEN-LAST:event_btnDeleteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmMain().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCapture;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnView;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblBusinessConferenceAttendanceRegister;
    private javax.swing.JLabel lblCompany;
    private javax.swing.JLabel lblCompany1;
    private javax.swing.JLabel lblDepartment;
    private javax.swing.JLabel lblEmployeeDateofBirth;
    private javax.swing.JLabel lblEmployeeFirstNameandLastName;
    private javax.swing.JLabel lblEmployeeGender;
    private javax.swing.JLabel lblEmployeeID;
    private javax.swing.JLabel lblPosition;
    private javax.swing.JTextField txtDepartment;
    private javax.swing.JLabel txtEmployeeContactInformation;
    private javax.swing.JTextField txtEmployeeDateofBirth;
    private javax.swing.JTextField txtEmployeeEmail;
    private javax.swing.JTextField txtEmployeeFirstNameandLastName;
    private javax.swing.JTextField txtEmployeeGender;
    private javax.swing.JTextField txtEmployeeID;
    private javax.swing.JTextField txtPosition;
    private javax.swing.JTextField txtStartingDate;
    // End of variables declaration//GEN-END:variables

  
}
